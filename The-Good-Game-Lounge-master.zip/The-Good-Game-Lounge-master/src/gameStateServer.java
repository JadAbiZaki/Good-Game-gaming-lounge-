
public abstract class gameStateServer {
	abstract public void updateState(String player, int y, int x);

	abstract public void updateState(String player, int oldx, int oldy, int newx, int newy, int piece) ;
		// TODO Auto-generated method stub
		
	}

